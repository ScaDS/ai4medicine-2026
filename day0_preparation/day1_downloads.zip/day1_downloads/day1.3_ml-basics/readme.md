# Machine Learning: Introduction and Basics

* Theory and Practice
* Introducing algorithms and models
* Handling of Python library scikit-learn

Slides used for this session can be downloaded as PDF [here](ml-basics.pdf)
